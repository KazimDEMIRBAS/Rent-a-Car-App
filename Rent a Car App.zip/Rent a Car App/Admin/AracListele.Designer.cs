﻿namespace Rent_a_Car_App
{
    partial class AracListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.renkText = new System.Windows.Forms.TextBox();
            this.serinoText = new System.Windows.Forms.TextBox();
            this.durumuText = new System.Windows.Forms.ComboBox();
            this.yakıtText = new System.Windows.Forms.ComboBox();
            this.markaText = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.idText = new System.Windows.Forms.TextBox();
            this.modelText = new System.Windows.Forms.MaskedTextBox();
            this.kmText = new System.Windows.Forms.MaskedTextBox();
            this.kiraText = new System.Windows.Forms.MaskedTextBox();
            this.plakaText = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 407);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 31);
            this.button2.TabIndex = 39;
            this.button2.Text = "Çıkış";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(51, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Güncelle";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // renkText
            // 
            this.renkText.Location = new System.Drawing.Point(130, 185);
            this.renkText.MaxLength = 20;
            this.renkText.Name = "renkText";
            this.renkText.Size = new System.Drawing.Size(121, 20);
            this.renkText.TabIndex = 6;
            // 
            // serinoText
            // 
            this.serinoText.Location = new System.Drawing.Point(130, 122);
            this.serinoText.MaxLength = 12;
            this.serinoText.Name = "serinoText";
            this.serinoText.Size = new System.Drawing.Size(121, 20);
            this.serinoText.TabIndex = 4;
            // 
            // durumuText
            // 
            this.durumuText.FormattingEnabled = true;
            this.durumuText.Location = new System.Drawing.Point(130, 327);
            this.durumuText.Name = "durumuText";
            this.durumuText.Size = new System.Drawing.Size(121, 21);
            this.durumuText.TabIndex = 10;
            // 
            // yakıtText
            // 
            this.yakıtText.FormattingEnabled = true;
            this.yakıtText.Location = new System.Drawing.Point(130, 254);
            this.yakıtText.Name = "yakıtText";
            this.yakıtText.Size = new System.Drawing.Size(121, 21);
            this.yakıtText.TabIndex = 8;
            // 
            // markaText
            // 
            this.markaText.FormattingEnabled = true;
            this.markaText.Items.AddRange(new object[] {
            "Aston Martin",
            "Audi",
            "Bentley",
            "BMW",
            "Bugatti",
            "Chevrolet",
            "Dodge",
            "Ferrari",
            "Fiat",
            "Ford",
            "Honda",
            "Hyundai",
            "Infiniti",
            "Jaguar",
            "Lamborghini",
            "Maserati",
            "Mercedes-Benz",
            "Mini",
            "Nissan",
            "Opel",
            "Porsche",
            "Renault",
            "Rolls-Royce",
            "Seat",
            "Skoda",
            "Tesla",
            "Toyota",
            "Volkswagen",
            "Volvo",
            "",
            "",
            "",
            ""});
            this.markaText.Location = new System.Drawing.Point(130, 87);
            this.markaText.Name = "markaText";
            this.markaText.Size = new System.Drawing.Size(121, 21);
            this.markaText.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(38, 332);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 16);
            this.label9.TabIndex = 28;
            this.label9.Text = "Durumu:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(16, 296);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 16);
            this.label8.TabIndex = 27;
            this.label8.Text = "Kira Ücreti:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(59, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "Yakıt:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 16);
            this.label6.TabIndex = 25;
            this.label6.Text = "Kilometre:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(59, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "Renk:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(68, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Seri:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Model(Yıl):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 21;
            this.label2.Text = "Marka:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "Plaka:";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Tomato;
            this.button3.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(157, 363);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "Sil";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(274, 15);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(766, 423);
            this.dataGridView1.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(77, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 16);
            this.label10.TabIndex = 20;
            this.label10.Text = "Id:";
            // 
            // idText
            // 
            this.idText.Location = new System.Drawing.Point(130, 15);
            this.idText.Name = "idText";
            this.idText.Size = new System.Drawing.Size(121, 20);
            this.idText.TabIndex = 1;
            // 
            // modelText
            // 
            this.modelText.Location = new System.Drawing.Point(130, 153);
            this.modelText.Mask = "0000";
            this.modelText.Name = "modelText";
            this.modelText.Size = new System.Drawing.Size(121, 20);
            this.modelText.TabIndex = 5;
            // 
            // kmText
            // 
            this.kmText.Location = new System.Drawing.Point(130, 223);
            this.kmText.Mask = "000000";
            this.kmText.Name = "kmText";
            this.kmText.Size = new System.Drawing.Size(121, 20);
            this.kmText.TabIndex = 7;
            // 
            // kiraText
            // 
            this.kiraText.Location = new System.Drawing.Point(130, 292);
            this.kiraText.Mask = "000000";
            this.kiraText.Name = "kiraText";
            this.kiraText.Size = new System.Drawing.Size(121, 20);
            this.kiraText.TabIndex = 9;
            // 
            // plakaText
            // 
            this.plakaText.Location = new System.Drawing.Point(130, 56);
            this.plakaText.MaxLength = 12;
            this.plakaText.Name = "plakaText";
            this.plakaText.Size = new System.Drawing.Size(121, 20);
            this.plakaText.TabIndex = 2;
            // 
            // AracListele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1055, 450);
            this.Controls.Add(this.kiraText);
            this.Controls.Add(this.kmText);
            this.Controls.Add(this.modelText);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.renkText);
            this.Controls.Add(this.idText);
            this.Controls.Add(this.plakaText);
            this.Controls.Add(this.serinoText);
            this.Controls.Add(this.durumuText);
            this.Controls.Add(this.yakıtText);
            this.Controls.Add(this.markaText);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AracListele";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AracListele";
            this.Load += new System.EventHandler(this.AracListele_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox renkText;
        private System.Windows.Forms.TextBox serinoText;
        private System.Windows.Forms.ComboBox durumuText;
        private System.Windows.Forms.ComboBox yakıtText;
        private System.Windows.Forms.ComboBox markaText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox idText;
        private System.Windows.Forms.MaskedTextBox modelText;
        private System.Windows.Forms.MaskedTextBox kmText;
        private System.Windows.Forms.MaskedTextBox kiraText;
        private System.Windows.Forms.TextBox plakaText;
    }
}