﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Rent_a_Car_App
{
    public partial class MusteriEkle : Form
    {
        
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public MusteriEkle()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void MusteriEkle_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "INSERT INTO `musteriler`(`id`, `tcno`, `adsoyad`, `telefonno`, `eposta`, `adres`) VALUES (NULL,'"+maskedTextBox2.Text+"','"+textBox2.Text+"','"+maskedTextBox1.Text+"','"+textBox4.Text+"','"+textBox5.Text+"')";
            MySqlCommand command = new MySqlCommand(query, conn);
            MySqlDataReader rdr;
            rdr = command.ExecuteReader();
            MessageBox.Show("Veri kaydedildi");
            this.Hide();
            conn.Close();
        }
    }
}
