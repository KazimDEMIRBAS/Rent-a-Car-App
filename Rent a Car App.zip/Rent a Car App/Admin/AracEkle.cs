﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Car_App
{
    public partial class AracEkle : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");

        public AracEkle()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void AracEkle_Load(object sender, EventArgs e)
        {
            string connStr = "server=localhost;user=root;database=rent_a_car;port=3306;password=secret";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                string sql = "SELECT id, name FROM brands";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                   comboBox1.Items.Add(rdr[1]);
                }
                rdr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            conn.Close();
            Console.WriteLine("Done.");
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "INSERT INTO `brands`(`id`, `plaka`, `marka`, `seri`, `model`, `renk`, `kilometre`, `yakıt`, `kirasi`, `durumu`) VALUES (NULL,'" + textBox2.Text + "','" + comboBox1.Text + "','" + textBox1.Text + "','" + Convert.ToInt32(maskedTextBox1.Text) + "','" + textBox4.Text + "','" + maskedTextBox2.Text + "','" + comboBox3.Text + "','" + maskedTextBox3.Text + "','" + comboBox4.Text + "')";
            MySqlCommand command = new MySqlCommand(query,conn);
            MySqlDataReader rdr;
            rdr = command.ExecuteReader();
            MessageBox.Show("Veri kaydedildi");
            this.Hide();
            conn.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
