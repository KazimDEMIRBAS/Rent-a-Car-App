﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rent_a_Car_App
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
        }

        private void button1_Click (object sender, EventArgs e)
        {
            MusteriEkle musterieklefrm = new MusteriEkle();
            musterieklefrm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AracEkle aracEkle = new AracEkle();
            aracEkle.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Satis satis = new Satis();  
            satis.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MusteriListele musteriListele = new MusteriListele();
            musteriListele.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AracListele aracListelefrm = new AracListele();
            aracListelefrm.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MusteriEkle musterieklefrm = new MusteriEkle();
            musterieklefrm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
         Giris giris = new Giris();
            giris.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Sozlesme sozlesme = new Sozlesme();
              sozlesme.Show();
        }

        private void AnaSayfa_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
