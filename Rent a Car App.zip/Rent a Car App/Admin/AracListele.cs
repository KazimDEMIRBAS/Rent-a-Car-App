﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Rent_a_Car_App
{
    public partial class AracListele : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public AracListele()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AracListele_Load(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "select * from brands;";
                MySqlCommand MyCommand2 = new MySqlCommand(query, conn);
                //  MyConn2.Open();
                //For offline connection we weill use  MySqlDataAdapter class.
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = MyCommand2;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata" + ex);
                throw;
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "UPDATE `brands` SET `plaka`='"+plakaText.Text+"',`marka`='"+markaText.Text+"',`seri`='"+serinoText.Text+"',`model`='"+Convert.ToInt32(modelText.Text)+"',`renk`='"+renkText.Text+"',`kilometre`='"+kmText.Text+"',`yakıt`='"+yakıtText.Text+"',`kirasi`='"+kiraText.Text+"',`durumu`='"+durumuText.Text+"' WHERE `id`='"+idText.Text+"'";
            MySqlCommand komut = new MySqlCommand(query, conn);
            MySqlDataReader okuyucu;
            okuyucu = komut.ExecuteReader();
            MessageBox.Show("Veri güncellendi");
            while (okuyucu.Read())
            {
            }
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "delete from brands where id='" + idText.Text + "';";
            MySqlCommand komut = new MySqlCommand(query, conn);
            MySqlDataReader reader;
            conn.Open();
            reader = komut.ExecuteReader();
            MessageBox.Show("Satır Silindi", "Kullanıcı Bilgisi");
            while (reader.Read())
            {
            }
            conn.Close();
        }
    }
}
