﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;




namespace Rent_a_Car_App
{
    public partial class MusteriListele : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public MusteriListele()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "update musteriler set tcno='" + maskedTextBox3.Text + "',adsoyad='" + textBox2.Text + "',telefonno='" + maskedTextBox2.Text + "',eposta='" + textBox4.Text + "',adres='" + textBox5.Text + "' where id='" + maskedTextBox3.Text + "';";
            //Burada nesneyi oluşturdum ve bağlantıyı birleştirdim.
            MySqlCommand MyCommand2 = new MySqlCommand(query, conn);
            MySqlDataReader MyReader2;
            MyReader2 = MyCommand2.ExecuteReader();
            MessageBox.Show("Data Updated");
            while (MyReader2.Read())
            {
            }
            conn.Close();//Connection closed here
        }

        private void MusteriListele_Load(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "select * from musteriler;";
                MySqlCommand MyCommand2 = new MySqlCommand(query, conn);
                //For offline connection we weill use  MySqlDataAdapter class.
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = MyCommand2;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata" + ex);
                throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "delete from musteriler where id='"+ maskedTextBox3.Text +"';";
            MySqlCommand komut = new MySqlCommand(query, conn);
            MySqlDataReader reader;
            conn.Open();
            reader = komut.ExecuteReader();
            MessageBox.Show("Satır Silindi", "Kullanıcı Bilgisi");
            while (reader.Read()) 
            { 
            }
            conn.Close();
        }
        
    }
}
