﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Rent_a_Car_App
{
    public partial class Sozlesme : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public Sozlesme()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Sozlesme_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO `sozlesme`(`musteri_id`, `arac_id`, `kira_sekli`, `gun`, `cikis_tarihi`, `teslim_tarihi`) VALUES ('" + idText.Text + "','" + maskedTextBox1.Text + "','" + comboBox2.Text + "','" + gunText.Text + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd HH:mm:ss") + "','" + dateTimePicker2.Value.ToString("dd-MM-yyyy HH:mm:ss") + "')";
                MySqlCommand command = new MySqlCommand(query, conn);
                MySqlDataReader rdr;
                rdr = command.ExecuteReader();
                MessageBox.Show("Veri kaydedildi");
                this.Hide();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata" + ex.Message);
                throw;
            }
        }

        private void Sozlesme_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }
    }
}
