﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Car_App
{
    public partial class Satis : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public Satis()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Satis_Load(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "select * from sozlesme;";
                MySqlCommand MyCommand2 = new MySqlCommand(query, conn);
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = MyCommand2;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata" + ex);
                throw;
            }
        }
    }
}
