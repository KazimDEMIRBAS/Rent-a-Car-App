﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_a_Car_App
{
    public partial class Kirala : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;user=root;database=rent_a_car;port=3306;password=secret");
        public Kirala()
        {
            InitializeComponent();
        }

        private void Kirala_FormClosed(object sender, FormClosedEventArgs e)
        {
            Giris giris = new Giris();
            this.Hide();
            giris.Show();
        }

        private void kaydetBtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "INSERT INTO `musteriler`(`tcno`, `adsoyad`, `telefonno`, `eposta`, `adres`) VALUES ('" + maskedTextBox2.Text + "','" + textBox2.Text + "','" + maskedTextBox1.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
            MySqlCommand command = new MySqlCommand(query, conn);
            MySqlDataReader rdr;
            rdr = command.ExecuteReader();
            groupBox2.Visible = true;
            MessageBox.Show("Veri kaydedildi");
            
            
            
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //
            conn.Open();
            string query = "INSERT INTO `talepler`(`marka`, `seri`, `model`, `renk`) VALUES ('"+comboBox1.Text+"','"+textBox1.Text+"','"+maskedTextBox6.Text+"','"+textBox3.Text+"')";
            MySqlCommand command = new MySqlCommand(query, conn);
            MySqlDataReader rdr;
            rdr = command.ExecuteReader();
            DialogResult dialog = new DialogResult();
            dialog = MessageBox.Show("Veri kaydedildi. Bilgileriniz işleme alınmıştır. Lütfen e-postanızı takip edin.", "Başarılı", MessageBoxButtons.OK);
            if (dialog == DialogResult.OK)
            {
                Giris giris = new Giris();
                giris.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Çıkış yapılmadı");
                Application.Exit();
            }
            conn.Close();
        }
    }
}
