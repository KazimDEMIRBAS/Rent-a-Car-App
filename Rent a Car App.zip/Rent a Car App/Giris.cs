﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Rent_a_Car_App
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }

        private void KiralaObje()
        {
            Kirala kirala = new Kirala();
            this.Hide();
            kirala.Show();
        }
        private void arabalarObje()
        {
            Arabalar arabalar = new Arabalar();
            this.Hide();
            arabalar.Show();
        }
        private void HakkımzdaObje()
        {
            Hakkımızda hakkımızda = new Hakkımızda();
            this.Hide();
            hakkımızda.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            AdminLogin adminLogin = new AdminLogin();
            this.Hide();
            adminLogin.Show();
        }

        private void Giris_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void Giris_Load(object sender, EventArgs e)
        {
            string bugun = "http://www.tcmb.gov.tr/kurlar/today.xml";
            var xmldoc = new XmlDocument();
            xmldoc.Load(bugun);
            DateTime tarih = Convert.ToDateTime(xmldoc.SelectSingleNode("//Tarih_Date").Attributes["Tarih"].Value);
            string USD = xmldoc.SelectSingleNode("Tarih_Date/Currency [@Kod='USD']/BanknoteSelling").InnerXml;
            label2.Text = string.Format("Tarih: {0} USD $: {1}",tarih.ToShortDateString(),USD);

            string EUR = xmldoc.SelectSingleNode("Tarih_Date/Currency [@Kod='EUR']/BanknoteSelling").InnerXml;
            label3.Text = string.Format("EUR €: {1}", tarih.ToShortDateString(), EUR);

            string POUND = xmldoc.SelectSingleNode("Tarih_Date/Currency [@Kod='GBP']/BanknoteSelling").InnerXml;
            label4.Text = string.Format("GBP £: {1}", tarih.ToShortDateString(), POUND);

        }

        private void panel1_Click(object sender, EventArgs e)
        {
            arabalarObje();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            arabalarObje();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            arabalarObje();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            arabalarObje();
        }

        private void panel3_Click(object sender, EventArgs e)
        {
            KiralaObje();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            KiralaObje();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            KiralaObje();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            KiralaObje();
        }

        private void panel5_Click(object sender, EventArgs e)
        {
            HakkımzdaObje();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            HakkımzdaObje();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            HakkımzdaObje();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            HakkımzdaObje();
        }
    }
}
