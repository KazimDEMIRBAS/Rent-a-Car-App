-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 02 Oca 2023, 23:56:51
-- Sunucu sürümü: 8.0.28
-- PHP Sürümü: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `rent_a_car`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(1, 'kazım', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `brands`
--

CREATE TABLE `brands` (
  `id` int NOT NULL,
  `plaka` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marka` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seri` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` int NOT NULL,
  `renk` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kilometre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `yakıt` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kirasi` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `durumu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `brands`
--

INSERT INTO `brands` (`id`, `plaka`, `marka`, `seri`, `model`, `renk`, `kilometre`, `yakıt`, `kirasi`, `durumu`) VALUES
(3, '42 yu 445', 'Bugatti', 'Veyron', 1999, 'Siyah', '2000', 'Benzin', '50000', 'Boş'),
(4, '43 t 4343', 'Dodge', 'Challanger', 2022, 'Siyah', '2200', 'benz,n', '2000', 'Boş');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `musteriler`
--

CREATE TABLE `musteriler` (
  `id` int NOT NULL,
  `tcno` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adsoyad` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefonno` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eposta` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adres` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `musteriler`
--

INSERT INTO `musteriler` (`id`, `tcno`, `adsoyad`, `telefonno`, `eposta`, `adres`) VALUES
(5, '5', 'Kazım Demirbaş', '32323232323', 'kazimherevelazim@hotmail.com', 'dsadsadsadas'),
(8, '23232323232', 'asdasdsadsa', '(232) 323-2323', 'dsakjbdjsa@dsadsa.com', 'dsadsadsa'),
(9, '32132132132', 'dasdsadsa dsadsada', '(432) 323-1232', 'sdadasdas@cfdsfds.com', 'dasdsadas'),
(10, '23232323232', 'adsadsadsa', '(231) 321-3123', 'dfasdssad@dsadsa.com', 'dsdasdsadsa'),
(11, '23321234567', 'dgjkhgxnbv bn', '(111) 111-1111', 'fddffghghk@.com', 'xcvbnmşlçk nbv'),
(12, '63564654654', 'dfvgetgrt', '(321) 312-3131', 'fghhdfghfd', 'vcxvcxv');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sozlesme`
--

CREATE TABLE `sozlesme` (
  `id` int NOT NULL,
  `musteri_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `arac_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kira_sekli` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gun` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cikis_tarihi` datetime(6) NOT NULL,
  `teslim_tarihi` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `sozlesme`
--

INSERT INTO `sozlesme` (`id`, `musteri_id`, `arac_id`, `kira_sekli`, `gun`, `cikis_tarihi`, `teslim_tarihi`) VALUES
(1, '3', '4', 'Haftalık', '7', '2022-12-26 21:08:35.000000', '2023-01-02 21:08:35.000000'),
(2, '3', '4', 'Günlük ', '1', '2023-01-01 00:00:00.000000', '2023-01-02 00:00:00.000000');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `talepler`
--

CREATE TABLE `talepler` (
  `id` int NOT NULL,
  `marka` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seri` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `renk` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `talepler`
--

INSERT INTO `talepler` (`id`, `marka`, `seri`, `model`, `renk`) VALUES
(1, 'Hyundai', 'dsadsa', '2022', 'sarı'),
(2, 'Ferrari', 'dsadsadsa', '2002', 'dsads'),
(3, 'BMW', '520', '1111', '1111 siyah'),
(4, 'Honda', 'dsadsa', '4321', 'fgxvc b');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `musteriler`
--
ALTER TABLE `musteriler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sozlesme`
--
ALTER TABLE `sozlesme`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `talepler`
--
ALTER TABLE `talepler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `musteriler`
--
ALTER TABLE `musteriler`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `sozlesme`
--
ALTER TABLE `sozlesme`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `talepler`
--
ALTER TABLE `talepler`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
